import express from 'express';
import dotenv from 'dotenv'
import morgan from 'morgan'
import os from'os';
console.log(`freemem ${os.freemem()}`);

import fs from 'fs';
console.log(`files ${fs.readdirSync('./')}`)

import EventEmitter from 'events';
const emitter=new EventEmitter();
emitter.on('messagelogged',(arg)=>{
    console.log(`listener called ${arg.id}`)
});
var data={id:1, url:'google.com'}
emitter.emit("messagelogged",data);


import http from 'http';
const server=http.createServer((req,res)=>{
    if(req.url==='/'){
        res.write('Hello World');
        res.end();
    }
});

server.on('connection',(socket)=>{
    console.log('New Connection started...')
});

server.listen(4000);
//Configure env
dotenv.config();
//rest object
const app=express();

//middlewares
app.use(express.json());
app.use(morgan('dev'))

app.get('/',(req,res)=>{
    res.send({
        message:'Welcome to Ecommerce'
    })
})

//Port
const PORT=process.env.PORT ||8080;

//run listen
app.listen(PORT,()=>{
    console.log(`Server running on ${PORT}`);
})