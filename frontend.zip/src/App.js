import './App.scss';
import { Counter } from "./features/counter/Counter";
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import TopNavBar from './features/Home/TopNavBar';
import Cart  from "./features/Cart/Cart";
import  Home from "./features/Home/Home";
import Footer from './features/Home/Footer';
import Contact from './features/Contact/Contact';
import Products from './features/Products/Products';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        {/* <Counter /> */}
        <TopNavBar />
        <Routes>
          <Route path="/"  element={<Home/>} />
          <Route path="/home" element={<Home/>} />
          <Route path="/products" element={<Products/>} />
          <Route path="/cart" element={<Cart/>} />
          <Route path="/contactus" element={<Contact/>} />
        </Routes>
      </BrowserRouter>
      <Footer />
    </div>
  );
}

export default App;
