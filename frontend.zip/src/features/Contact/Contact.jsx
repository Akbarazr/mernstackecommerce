import React from 'react'

const Contact = () => {
  return (
    <div>Contact us</div>
  )
}

export default Contact