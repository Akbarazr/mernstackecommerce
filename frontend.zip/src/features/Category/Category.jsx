import { Card } from "react-bootstrap"
import { Link } from "react-router-dom"
import "./Category.scss"

const Category = ({ category }) => {
    return (
        <Link to={`category/${category}`} className="text-decoration-none text-dark" >
            <Card className="custom-card">
                <Card.Body>
                    <Card.Text>
                        {category}
                    </Card.Text>
                </Card.Body>
            </Card>
        </Link>
    )
}

export default Category