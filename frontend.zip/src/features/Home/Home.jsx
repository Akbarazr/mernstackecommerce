import React from 'react';
import Categories from '../Categories/Categories';
import HeaderSlider from '../Slider/HeaderSlider';

function Home() {
    console.log('Home entered');
    return (
        <>
            <HeaderSlider />
            <Categories />
        </>
    )
}

export default Home;