import { Button, Carousel, CarouselItem } from "react-bootstrap";
import lassi from "../../images/lassifruits.png";
import malai from "../../images/lassimalai.png";
import dryfruits from "../../images/dryfruits.png";

const HeaderSlider = () => {
    return (
        <Carousel variant="dark">
            <Carousel.Item>
                <img src={lassi} alt="item image" className="d-block w-100"
                    style={{ height: "100vh", objectFit: "cover" }} />
                    <Carousel.Caption className="bg-white">
                <h5>Malai Lassi</h5>
                <p>Lassi topped with Malai</p>
                <div className="mb-3">
                    <Button variant="dark">Shop Now</Button>
                </div>
            </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
                <img src={malai} alt="item image" className="d-block w-100"
                    style={{ height: "100vh", objectFit: "cover" }} />
                    <Carousel.Caption className="bg-white">
                <h5>Malai Lassi</h5>
                <p>Lassi topped with Malai</p>
                <div className="mb-3">
                    <Button variant="dark">Shop Now</Button>
                </div>
            </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
                <img src={dryfruits} alt="item image" className="d-block w-100"
                    style={{ height: "100vh", objectFit: "cover" }} />
                    <Carousel.Caption className="bg-white">
                <h5>Malai Lassi</h5>
                <p>Lassi topped with Malai</p>
                <div className="mb-3">
                    <Button variant="dark">Shop Now</Button>
                </div>
            </Carousel.Caption>
            </Carousel.Item>
        </Carousel>
    )
}

export default HeaderSlider