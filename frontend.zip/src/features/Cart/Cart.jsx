import { Button } from 'react-bootstrap';

function Cart() {
  console.log('Cart entered');
  return (
    <><div>Cart</div>
    <Button>Bootstrap Button</Button>
    </>
  )
}

export default Cart;