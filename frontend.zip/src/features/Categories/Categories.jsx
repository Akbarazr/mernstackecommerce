import { Col, Container, Row } from "react-bootstrap";
import Category from "../Category/Category";


function Categories() {
  return (
   <Container className="mb-5">
    <h3 className="text-center mb-4">Browse Categories</h3>
    <Row>
        <Col xs={12} sm={6} md={3} className="mb-2 p-0">
            <Category category={"Kaju Lassi"} />
        </Col>
    </Row>
    </Container>
  )
}

export default Categories