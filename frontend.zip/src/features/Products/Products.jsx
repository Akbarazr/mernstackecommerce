import React, { useEffect, useState } from 'react'
import { Col, Container, Row } from 'react-bootstrap';
import ProductCard from '../Product/ProductCard';

const Products = () => {
    const [products,setProducts]=useState([]);
    useEffect(()=>{
        fetch('https://fakestoreapi.com/products?limit=5')
        .then(res=>res.json())
        .then(json=>{console.log(json);setProducts(json)})
    },[]);
  return (
    <>
    <Container>
        <h3 className='text-center mb-3'>Products</h3>
        <Row>
    {products.length!=0 && products.map((product)=>{
        return (  <Col xs={12} sm={6} md={4} lg={2}>
        <ProductCard product={product} /></Col>
        )
    })}
    </Row>
    </Container>
    </>
  )
}

export default Products