import { Card } from "react-bootstrap";
import { Link } from "react-router-dom";
import "./Productcard.scss";

const ProductCard = ({product}) => {
  
  return (
   <>
   <Link to={`product/${product.id}`}>
    <Card className="custom-card">
      <Card.Img variant="top" src={product.image} className="py-3 card-img"/>
        <Card.Body className="text-center">
          <Card.Title className="fs-6">
            {product.title.slice(0,30)}
          </Card.Title>
          <Card.Text className="text-decoration-none fs-6">
            {product.category}
          </Card.Text>
          <Card.Text className="text-decoration-none fs-6">
            Rs.{product.price}
          </Card.Text>
        </Card.Body>
      
    </Card>
   </Link>
   </>
  )
}

export default ProductCard